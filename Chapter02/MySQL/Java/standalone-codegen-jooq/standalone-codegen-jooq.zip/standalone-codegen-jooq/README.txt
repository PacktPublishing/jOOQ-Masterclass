Execute from command line:

java -cp jooq-3.15.5.jar;jooq-meta-3.15.5.jar;jooq-codegen-3.15.5.jar;jaxb-api-2.3.1.jar;
reactive-streams-1.0.2.jar;r2dbc-spi-1.0.0.M6.jar;mysql-connector-java-8.0.21.jar 
org.jooq.codegen.GenerationTool library.xml